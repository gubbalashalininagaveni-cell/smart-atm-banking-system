# Smart ATM & Banking System
## C++ + HTML + CSS + JavaScript

This is a college demonstration project. It uses DEMO banking data only.
It does not connect to real banks, payment gateways, cards, or financial accounts.

## Technology
- C++17
- Windows Winsock2 for the HTTP server
- HTML
- CSS
- JavaScript Fetch API
- In-memory demo data

## Project structure

smart_atm_banking_cpp/
|
|-- server.cpp
|-- README.md
|-- run.bat
|
`-- public/
    |-- index.html
    |-- style.css
    `-- script.js

## Demo accounts

Account: 100001
PIN: 1234

Account: 100002
PIN: 4321

## How to run on Windows

### Method 1: MinGW g++

Install a C++ compiler such as MinGW-w64 and make sure `g++` is available in Command Prompt.

Open Command Prompt in this project folder and run:

g++ -std=c++17 server.cpp -lws2_32 -o server.exe

Then:

server.exe

Open this in your browser:

http://localhost:8080

### Method 2: Use run.bat

Double-click `run.bat`.

If g++ is installed and available in PATH, it will compile and start the server.

## Features

- Login
- Account balance
- Deposit
- Withdraw
- Transfer
- Transaction history
- Account details
- Logout
- Responsive design
- C++ backend
- Browser frontend

## Important

This implementation is designed for learning/demo purposes.

It is NOT production banking software. Password/PIN handling, sessions,
database storage, HTTPS, validation, authorization, audit logging, and
security would need major improvements before any real-world use.
