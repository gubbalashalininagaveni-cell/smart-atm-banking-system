#include <winsock2.h>
#include <ws2tcpip.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <vector>
#include <ctime>
#include <iomanip>
#include <random>

#pragma comment(lib, "ws2_32.lib")

using namespace std;

struct Transaction {
    string type;
    double amount;
    string description;
    string date;
};

struct Account {
    string accountNumber;
    string pin;
    string name;
    string email;
    double balance;
    vector<Transaction> transactions;
};

map<string, Account> accounts;
map<string, string> sessions; // token -> account number

string now() {
    time_t t = time(nullptr);
    tm localTime{};
    localtime_s(&localTime, &t);

    stringstream ss;
    ss << put_time(&localTime, "%Y-%m-%d %H:%M:%S");
    return ss.str();
}

string jsonEscape(const string& s) {
    string out;
    for (char c : s) {
        if (c == '"') out += "\\\"";
        else if (c == '\\') out += "\\\\";
        else if (c == '\n') out += "\\n";
        else if (c == '\r') out += "\\r";
        else out += c;
    }
    return out;
}

string money(double value) {
    stringstream ss;
    ss << fixed << setprecision(2) << value;
    return ss.str();
}

string urlDecode(const string& input) {
    string result;
    for (size_t i = 0; i < input.size(); ++i) {
        if (input[i] == '+') {
            result += ' ';
        } else if (input[i] == '%' && i + 2 < input.size()) {
            string hex = input.substr(i + 1, 2);
            char ch = static_cast<char>(strtol(hex.c_str(), nullptr, 16));
            result += ch;
            i += 2;
        } else {
            result += input[i];
        }
    }
    return result;
}

map<string, string> parseForm(const string& body) {
    map<string, string> data;
    stringstream ss(body);
    string part;

    while (getline(ss, part, '&')) {
        size_t eq = part.find('=');
        if (eq != string::npos) {
            string key = urlDecode(part.substr(0, eq));
            string value = urlDecode(part.substr(eq + 1));
            data[key] = value;
        }
    }
    return data;
}

string generateToken() {
    static random_device rd;
    static mt19937 gen(rd());
    uniform_int_distribution<unsigned long long> dist;
    stringstream ss;
    ss << hex << dist(gen) << dist(gen);
    return ss.str();
}

void addTransaction(Account& acc, const string& type, double amount, const string& description) {
    acc.transactions.push_back({type, amount, description, now()});
}

string accountJson(const Account& acc) {
    stringstream ss;
    ss << "{";
    ss << "\"accountNumber\":\"" << jsonEscape(acc.accountNumber) << "\",";
    ss << "\"name\":\"" << jsonEscape(acc.name) << "\",";
    ss << "\"email\":\"" << jsonEscape(acc.email) << "\",";
    ss << "\"balance\":" << money(acc.balance);
    ss << "}";
    return ss.str();
}

string transactionsJson(const Account& acc) {
    stringstream ss;
    ss << "[";
    for (size_t i = 0; i < acc.transactions.size(); ++i) {
        const auto& t = acc.transactions[i];
        if (i > 0) ss << ",";
        ss << "{";
        ss << "\"type\":\"" << jsonEscape(t.type) << "\",";
        ss << "\"amount\":" << money(t.amount) << ",";
        ss << "\"description\":\"" << jsonEscape(t.description) << "\",";
        ss << "\"date\":\"" << jsonEscape(t.date) << "\"";
        ss << "}";
    }
    ss << "]";
    return ss.str();
}

string response(const string& body, const string& contentType = "application/json", int status = 200) {
    string statusText = status == 200 ? "OK" : (status == 400 ? "Bad Request" : "Unauthorized");
    stringstream ss;
    ss << "HTTP/1.1 " << status << " " << statusText << "\r\n";
    ss << "Content-Type: " << contentType << "; charset=utf-8\r\n";
    ss << "Access-Control-Allow-Origin: *\r\n";
    ss << "Access-Control-Allow-Headers: Content-Type, Authorization\r\n";
    ss << "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n";
    ss << "Content-Length: " << body.size() << "\r\n";
    ss << "Connection: close\r\n\r\n";
    ss << body;
    return ss.str();
}

string errorJson(const string& message, int status = 400) {
    return response("{\"success\":false,\"message\":\"" + jsonEscape(message) + "\"}", "application/json", status);
}

string successJson(const string& extra = "") {
    return response("{\"success\":true" + extra + "}");
}

string getHeader(const string& request, const string& headerName) {
    string key = headerName + ":";
    size_t pos = request.find(key);
    if (pos == string::npos) return "";

    size_t start = pos + key.size();
    while (start < request.size() && request[start] == ' ') start++;

    size_t end = request.find("\r\n", start);
    if (end == string::npos) return "";
    return request.substr(start, end - start);
}

string serveFile(const string& path) {
    string filePath = "public" + path;
    if (path == "/") filePath = "public/index.html";

    ifstream file(filePath, ios::binary);
    if (!file) {
        return response("<h1>404 - Page Not Found</h1>", "text/html", 404);
    }

    stringstream buffer;
    buffer << file.rdbuf();

    string contentType = "text/plain";
    if (path.ends_with(".html")) contentType = "text/html";
    else if (path.ends_with(".css")) contentType = "text/css";
    else if (path.ends_with(".js")) contentType = "application/javascript";
    else if (path.ends_with(".svg")) contentType = "image/svg+xml";

    return response(buffer.str(), contentType);
}

void initializeAccounts() {
    accounts["100001"] = {
        "100001", "1234", "Shalini Demo", "shalini@example.com", 25000.00,
        {
            {"Deposit", 10000.00, "Initial demo deposit", "2026-09-20 10:00:00"},
            {"Withdrawal", 1500.00, "ATM cash withdrawal", "2026-09-21 14:30:00"},
            {"Transfer", 2500.00, "Demo transfer", "2026-09-22 11:15:00"}
        }
    };

    accounts["100002"] = {
        "100002", "4321", "Rahul Demo", "rahul@example.com", 15000.00,
        {
            {"Deposit", 15000.00, "Initial demo deposit", "2026-09-20 09:00:00"}
        }
    };
}

string handleApi(const string& method, const string& path, const string& request, const string& body) {
    if (method == "OPTIONS") return response("");

    if (path == "/api/login" && method == "POST") {
        auto form = parseForm(body);
        string account = form["accountNumber"];
        string pin = form["pin"];

        auto it = accounts.find(account);
        if (it == accounts.end() || it->second.pin != pin) {
            return errorJson("Invalid account number or PIN.", 401);
        }

        string token = generateToken();
        sessions[token] = account;

        return successJson(
            ",\"token\":\"" + token + "\",\"account\":" + accountJson(it->second)
        );
    }

    string auth = getHeader(request, "Authorization");
    string token = auth.rfind("Bearer ", 0) == 0 ? auth.substr(7) : "";

    auto sessionIt = sessions.find(token);
    if (sessionIt == sessions.end()) {
        return errorJson("Please log in first.", 401);
    }

    Account& acc = accounts[sessionIt->second];

    if (path == "/api/account" && method == "GET") {
        return successJson(",\"account\":" + accountJson(acc));
    }

    if (path == "/api/transactions" && method == "GET") {
        return successJson(",\"transactions\":" + transactionsJson(acc));
    }

    if (path == "/api/deposit" && method == "POST") {
        auto form = parseForm(body);
        double amount = stod(form["amount"]);

        if (amount <= 0 || amount > 1000000) return errorJson("Enter a valid deposit amount.");
        acc.balance += amount;
        addTransaction(acc, "Deposit", amount, "Cash deposit");
        return successJson(",\"message\":\"Deposit successful.\",\"account\":" + accountJson(acc));
    }

    if (path == "/api/withdraw" && method == "POST") {
        auto form = parseForm(body);
        double amount = stod(form["amount"]);

        if (amount <= 0) return errorJson("Enter a valid withdrawal amount.");
        if (amount > acc.balance) return errorJson("Insufficient balance.");

        acc.balance -= amount;
        addTransaction(acc, "Withdrawal", amount, "ATM cash withdrawal");
        return successJson(",\"message\":\"Withdrawal successful.\",\"account\":" + accountJson(acc));
    }

    if (path == "/api/transfer" && method == "POST") {
        auto form = parseForm(body);
        string target = form["toAccount"];
        double amount = stod(form["amount"]);

        if (accounts.find(target) == accounts.end()) return errorJson("Destination account not found.");
        if (target == acc.accountNumber) return errorJson("You cannot transfer to the same account.");
        if (amount <= 0) return errorJson("Enter a valid transfer amount.");
        if (amount > acc.balance) return errorJson("Insufficient balance.");

        Account& receiver = accounts[target];
        acc.balance -= amount;
        receiver.balance += amount;

        addTransaction(acc, "Transfer", amount, "Transfer to account " + target);
        addTransaction(receiver, "Received", amount, "Received from account " + acc.accountNumber);

        return successJson(",\"message\":\"Transfer successful.\",\"account\":" + accountJson(acc));
    }

    if (path == "/api/logout" && method == "POST") {
        sessions.erase(token);
        return successJson(",\"message\":\"Logged out successfully.\"");
    }

    return errorJson("API endpoint not found.", 404);
}

void handleClient(SOCKET client) {
    char buffer[8192];
    string request;

    int received = recv(client, buffer, sizeof(buffer) - 1, 0);
    if (received <= 0) {
        closesocket(client);
        return;
    }

    buffer[received] = '\0';
    request = buffer;

    size_t requestLineEnd = request.find("\r\n");
    if (requestLineEnd == string::npos) {
        closesocket(client);
        return;
    }

    string requestLine = request.substr(0, requestLineEnd);
    stringstream rl(requestLine);

    string method, path, version;
    rl >> method >> path >> version;

    size_t headerEnd = request.find("\r\n\r\n");
    string body = headerEnd != string::npos ? request.substr(headerEnd + 4) : "";

    string contentLengthHeader = getHeader(request, "Content-Length");
    if (!contentLengthHeader.empty()) {
        int contentLength = stoi(contentLengthHeader);
        while ((int)body.size() < contentLength) {
            int more = recv(client, buffer, sizeof(buffer) - 1, 0);
            if (more <= 0) break;
            buffer[more] = '\0';
            body += buffer;
        }
    }

    string result;

    if (path.rfind("/api/", 0) == 0) {
        result = handleApi(method, path, request, body);
    } else {
        result = serveFile(path);
    }

    send(client, result.c_str(), static_cast<int>(result.size()), 0);
    closesocket(client);
}

int main() {
    initializeAccounts();

    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        cerr << "WSAStartup failed.\n";
        return 1;
    }

    SOCKET serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket == INVALID_SOCKET) {
        cerr << "Could not create socket.\n";
        WSACleanup();
        return 1;
    }

    int opt = 1;
    setsockopt(serverSocket, SOL_SOCKET, SO_REUSEADDR, (char*)&opt, sizeof(opt));

    sockaddr_in serverAddress{};
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_addr.s_addr = INADDR_ANY;
    serverAddress.sin_port = htons(8080);

    if (bind(serverSocket, (sockaddr*)&serverAddress, sizeof(serverAddress)) == SOCKET_ERROR) {
        cerr << "Bind failed. Make sure port 8080 is free.\n";
        closesocket(serverSocket);
        WSACleanup();
        return 1;
    }

    if (listen(serverSocket, SOMAXCONN) == SOCKET_ERROR) {
        cerr << "Listen failed.\n";
        closesocket(serverSocket);
        WSACleanup();
        return 1;
    }

    cout << "========================================\n";
    cout << " Smart ATM & Banking System\n";
    cout << " C++ Web Server\n";
    cout << "========================================\n";
    cout << "Open: http://localhost:8080\n";
    cout << "Demo Account: 100001\n";
    cout << "Demo PIN:     1234\n";
    cout << "========================================\n";

    while (true) {
        SOCKET client = accept(serverSocket, nullptr, nullptr);
        if (client != INVALID_SOCKET) {
            handleClient(client);
        }
    }

    closesocket(serverSocket);
    WSACleanup();
    return 0;
}
