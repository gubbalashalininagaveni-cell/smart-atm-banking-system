let token = sessionStorage.getItem("atmToken");
let currentAccount = null;

const loginPage = document.getElementById("loginPage");
const dashboardPage = document.getElementById("dashboardPage");
const contentPanel = document.getElementById("contentPanel");

function showToast(message) {
    const toast = document.getElementById("toast");
    toast.textContent = message;
    toast.classList.add("show");
    setTimeout(() => toast.classList.remove("show"), 2500);
}

async function api(path, options = {}) {
    const headers = options.headers || {};
    headers["Content-Type"] = "application/x-www-form-urlencoded";

    if (token) {
        headers["Authorization"] = `Bearer ${token}`;
    }

    const response = await fetch(path, { ...options, headers });
    const data = await response.json();

    if (!response.ok) {
        throw new Error(data.message || "Something went wrong.");
    }

    return data;
}

function formatMoney(value) {
    return "₹" + Number(value).toLocaleString("en-IN", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

function updateDashboard(account) {
    currentAccount = account;
    document.getElementById("balance").textContent = formatMoney(account.balance);
    document.getElementById("accountDisplay").textContent = account.accountNumber;
    document.getElementById("welcomeName").textContent = account.name;
    document.getElementById("userName").textContent = account.name;
}

async function loadAccount() {
    const data = await api("/api/account");
    updateDashboard(data.account);
    await loadTransactionCount();
}

async function loadTransactionCount() {
    try {
        const data = await api("/api/transactions");
        document.getElementById("transactionCount").textContent = data.transactions.length;
    } catch (e) {}
}

function showLogin() {
    loginPage.classList.remove("hidden");
    dashboardPage.classList.add("hidden");
}

function showDashboard() {
    loginPage.classList.add("hidden");
    dashboardPage.classList.remove("hidden");
}

document.getElementById("loginForm").addEventListener("submit", async (event) => {
    event.preventDefault();

    const accountNumber = document.getElementById("accountNumber").value.trim();
    const pin = document.getElementById("pin").value.trim();

    try {
        const data = await api("/api/login", {
            method: "POST",
            body: `accountNumber=${encodeURIComponent(accountNumber)}&pin=${encodeURIComponent(pin)}`
        });

        token = data.token;
        sessionStorage.setItem("atmToken", token);
        updateDashboard(data.account);
        showDashboard();
        showToast("Login successful");
        document.getElementById("loginForm").reset();
    } catch (error) {
        showToast(error.message);
    }
});

document.getElementById("logoutBtn").addEventListener("click", async () => {
    try {
        await api("/api/logout", { method: "POST", body: "" });
    } catch (e) {}

    token = null;
    currentAccount = null;
    sessionStorage.removeItem("atmToken");
    showLogin();
    showToast("Logged out");
});

document.querySelectorAll(".action-card").forEach(button => {
    button.addEventListener("click", () => {
        const action = button.dataset.action;

        if (action === "deposit") showMoneyForm("Deposit Money", "deposit");
        if (action === "withdraw") showMoneyForm("Withdraw Money", "withdraw");
        if (action === "transfer") showTransferForm();
        if (action === "transactions") showTransactions();
        if (action === "account") showAccountDetails();
    });
});

function showMoneyForm(title, endpoint) {
    contentPanel.innerHTML = `
        <div class="form-box">
            <h3>${title}</h3>
            <p>Enter the amount for this demo transaction.</p>

            <form id="moneyForm">
                <label>Amount (₹)</label>
                <input id="amount" type="number" min="1" step="0.01" placeholder="Enter amount" required>
                <button class="primary-btn" type="submit">Confirm</button>
            </form>
            <div id="formMessage"></div>
        </div>
    `;

    document.getElementById("moneyForm").addEventListener("submit", async (event) => {
        event.preventDefault();

        const amount = document.getElementById("amount").value;

        try {
            const data = await api(`/api/${endpoint}`, {
                method: "POST",
                body: `amount=${encodeURIComponent(amount)}`
            });

            updateDashboard(data.account);
            await loadTransactionCount();
            document.getElementById("formMessage").innerHTML =
                `<div class="message">${data.message}</div>`;
            showToast(data.message);
        } catch (error) {
            document.getElementById("formMessage").innerHTML =
                `<div class="error">${error.message}</div>`;
        }
    });
}

function showTransferForm() {
    contentPanel.innerHTML = `
        <div class="form-box">
            <h3>Transfer Money</h3>
            <p>Transfer demo money to another demo account.</p>

            <form id="transferForm">
                <label>Destination Account</label>
                <input id="toAccount" type="text" placeholder="Example: 100002" required>

                <label>Amount (₹)</label>
                <input id="transferAmount" type="number" min="1" step="0.01" placeholder="Enter amount" required>

                <button class="primary-btn" type="submit">Transfer</button>
            </form>

            <div id="transferMessage"></div>
            <div class="demo-box">
                <small>Available demo destination: <b>100002</b></small>
            </div>
        </div>
    `;

    document.getElementById("transferForm").addEventListener("submit", async (event) => {
        event.preventDefault();

        const toAccount = document.getElementById("toAccount").value.trim();
        const amount = document.getElementById("transferAmount").value;

        try {
            const data = await api("/api/transfer", {
                method: "POST",
                body: `toAccount=${encodeURIComponent(toAccount)}&amount=${encodeURIComponent(amount)}`
            });

            updateDashboard(data.account);
            await loadTransactionCount();

            document.getElementById("transferMessage").innerHTML =
                `<div class="message">${data.message}</div>`;
            showToast(data.message);
        } catch (error) {
            document.getElementById("transferMessage").innerHTML =
                `<div class="error">${error.message}</div>`;
        }
    });
}

async function showTransactions() {
    try {
        const data = await api("/api/transactions");

        let rows = "";

        if (data.transactions.length === 0) {
            rows = `<tr><td colspan="4">No transactions available.</td></tr>`;
        } else {
            [...data.transactions].reverse().forEach(t => {
                rows += `
                    <tr>
                        <td class="${t.type.toLowerCase()}">${t.type}</td>
                        <td>${formatMoney(t.amount)}</td>
                        <td>${t.description}</td>
                        <td>${t.date}</td>
                    </tr>
                `;
            });
        }

        contentPanel.innerHTML = `
            <h3>Transaction History</h3>
            <p class="muted">Recent activity for account ${currentAccount.accountNumber}</p>

            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Type</th>
                            <th>Amount</th>
                            <th>Description</th>
                            <th>Date & Time</th>
                        </tr>
                    </thead>
                    <tbody>${rows}</tbody>
                </table>
            </div>
        `;
    } catch (error) {
        contentPanel.innerHTML = `<div class="error">${error.message}</div>`;
    }
}

function showAccountDetails() {
    contentPanel.innerHTML = `
        <h3>Account Details</h3>
        <p class="muted">Demo profile information</p>

        <div class="account-details">
            <div class="detail">
                <span>Account Holder</span>
                <strong>${currentAccount.name}</strong>
            </div>
            <div class="detail">
                <span>Account Number</span>
                <strong>${currentAccount.accountNumber}</strong>
            </div>
            <div class="detail">
                <span>Email</span>
                <strong>${currentAccount.email}</strong>
            </div>
            <div class="detail">
                <span>Current Balance</span>
                <strong>${formatMoney(currentAccount.balance)}</strong>
            </div>
            <div class="detail">
                <span>Account Status</span>
                <strong>Active</strong>
            </div>
            <div class="detail">
                <span>Data Type</span>
                <strong>Demo / Educational</strong>
            </div>
        </div>
    `;
}

if (token) {
    loadAccount()
        .then(showDashboard)
        .catch(() => {
            token = null;
            sessionStorage.removeItem("atmToken");
            showLogin();
        });
} else {
    showLogin();
}
