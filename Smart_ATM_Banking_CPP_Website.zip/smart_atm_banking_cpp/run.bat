@echo off
echo ==========================================
echo   Smart ATM & Banking System
echo ==========================================
echo.

g++ -std=c++17 server.cpp -lws2_32 -o server.exe

if errorlevel 1 (
    echo.
    echo Compilation failed.
    echo Make sure MinGW-w64 / g++ is installed and added to PATH.
    pause
    exit /b
)

echo.
echo Starting C++ web server...
echo Open http://localhost:8080 in your browser.
echo.
server.exe
pause
